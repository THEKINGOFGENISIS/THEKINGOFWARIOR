import os
import random
import sqlite3
import time
from datetime import datetime, timezone

import discord
from discord import app_commands
from discord.ext import commands, tasks

TOKEN = os.getenv("DISCORD_TOKEN")
DB_PATH = os.getenv("DATABASE_PATH", "thewarrior.sqlite3")
MESSAGE_REWARD = 250
MESSAGE_COOLDOWN_SECONDS = 10
BUY_TAX_RATE = 0.20
STOCK_REFRESH_SECONDS = 3600
TRANSFER_TAX_MIN = 0.05
TRANSFER_TAX_MAX = 0.15
EXCHANGE_TOKEN_PER_XU = 1000  # 10 Xu = 10,000 Token

PRODUCTS = {
    "VIP": {"price": 5000, "currency": "token"},
    "Premium": {"price": 15000, "currency": "token"},
    "Custom Role": {"price": 5, "currency": "xu"},
    "Name Color": {"price": 3, "currency": "xu"},
    "Special Item": {"price": 25000, "currency": "token"},
}

intents = discord.Intents.default()
intents.guilds = True
intents.members = True
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

def connect():
    con = sqlite3.connect(DB_PATH, timeout=20)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA foreign_keys=ON")
    return con

def init_db():
    with connect() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS wallets (
            guild_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            token INTEGER NOT NULL DEFAULT 0 CHECK(token >= 0),
            xu INTEGER NOT NULL DEFAULT 0 CHECK(xu >= 0),
            PRIMARY KEY(guild_id, user_id)
        );
        CREATE TABLE IF NOT EXISTS inventory (
            guild_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            item TEXT NOT NULL,
            quantity INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(guild_id, user_id, item)
        );
        CREATE TABLE IF NOT EXISTS stock (
            guild_id INTEGER NOT NULL,
            item TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            refreshed_at INTEGER NOT NULL,
            PRIMARY KEY(guild_id, item)
        );
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id INTEGER NOT NULL,
            actor_id INTEGER NOT NULL,
            target_id INTEGER,
            kind TEXT NOT NULL,
            currency TEXT NOT NULL,
            amount INTEGER NOT NULL,
            tax INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS message_cooldowns (
            guild_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            last_reward INTEGER NOT NULL,
            PRIMARY KEY(guild_id, user_id)
        );
        """)
        now = int(time.time())
        for guild in bot.guilds:
            ensure_wallet(con, guild.id, bot.user.id if bot.user else 0)
            refresh_stock_if_needed(con, guild.id, now)

def ensure_wallet(con, guild_id, user_id):
    con.execute(
        "INSERT OR IGNORE INTO wallets(guild_id,user_id,token,xu) VALUES(?,?,0,0)",
        (guild_id, user_id),
    )

def refresh_stock_if_needed(con, guild_id, now=None):
    now = now or int(time.time())
    row = con.execute(
        "SELECT MAX(refreshed_at) AS t FROM stock WHERE guild_id=?", (guild_id,)
    ).fetchone()
    last = row["t"] if row and row["t"] is not None else 0
    if now - last < STOCK_REFRESH_SECONDS:
        return False
    con.execute("DELETE FROM stock WHERE guild_id=?", (guild_id,))
    for item in PRODUCTS:
        con.execute(
            "INSERT INTO stock(guild_id,item,quantity,refreshed_at) VALUES(?,?,?,?)",
            (guild_id, item, random.randint(2, 15), now),
        )
    return True

def get_balance(guild_id, user_id):
    with connect() as con:
        ensure_wallet(con, guild_id, user_id)
        row = con.execute(
            "SELECT token,xu FROM wallets WHERE guild_id=? AND user_id=?",
            (guild_id, user_id),
        ).fetchone()
        return int(row["token"]), int(row["xu"])

def money(value):
    return f"{value:,}"

def embed(title, description=None, color=0xA00020):
    e = discord.Embed(title=title, description=description, color=color)
    e.set_footer(text="TheWarrior • Economy")
    return e

def guild_only(interaction: discord.Interaction):
    return interaction.guild is not None

@bot.event
async def on_ready():
    init_db()
    try:
        synced = await bot.tree.sync()
        print(f"Đã đăng nhập: {bot.user} | Đồng bộ {len(synced)} slash commands")
    except Exception as exc:
        print(f"Lỗi đồng bộ lệnh: {exc}")
    if not stock_loop.is_running():
        stock_loop.start()

@tasks.loop(minutes=1)
async def stock_loop():
    now = int(time.time())
    with connect() as con:
        for guild in bot.guilds:
            refresh_stock_if_needed(con, guild.id, now)

@bot.event
async def on_guild_join(guild):
    with connect() as con:
        refresh_stock_if_needed(con, guild.id)

@bot.event
async def on_message(message: discord.Message):
    if message.author.bot or message.webhook_id or not message.guild:
        return
    if not message.content.strip() or message.content.startswith("/"):
        return
    now = int(time.time())
    with connect() as con:
        ensure_wallet(con, message.guild.id, message.author.id)
        row = con.execute(
            "SELECT last_reward FROM message_cooldowns WHERE guild_id=? AND user_id=?",
            (message.guild.id, message.author.id),
        ).fetchone()
        if row and now - int(row["last_reward"]) < MESSAGE_COOLDOWN_SECONDS:
            return
        con.execute(
            "UPDATE wallets SET token=token+? WHERE guild_id=? AND user_id=?",
            (MESSAGE_REWARD, message.guild.id, message.author.id),
        )
        con.execute(
            """INSERT INTO message_cooldowns(guild_id,user_id,last_reward)
               VALUES(?,?,?) ON CONFLICT(guild_id,user_id)
               DO UPDATE SET last_reward=excluded.last_reward""",
            (message.guild.id, message.author.id, now),
        )
        con.execute(
            """INSERT INTO transactions
               (guild_id,actor_id,kind,currency,amount,tax,created_at)
               VALUES(?,?, 'message_reward','token',?,0,?)""",
            (message.guild.id, message.author.id, MESSAGE_REWARD, now),
        )
    await bot.process_commands(message)

@bot.tree.command(name="status", description="Xem số dư Token và Xu của bạn")
@app_commands.check(guild_only)
async def status(interaction: discord.Interaction):
    token, xu = get_balance(interaction.guild_id, interaction.user.id)
    with connect() as con:
        count = con.execute(
            "SELECT COUNT(*) AS n FROM transactions WHERE guild_id=? AND (actor_id=? OR target_id=?)",
            (interaction.guild_id, interaction.user.id, interaction.user.id),
        ).fetchone()["n"]
    e = embed("💳 Số dư của bạn")
    e.add_field(name="Token 💶", value=money(token), inline=True)
    e.add_field(name="Xu 💵", value=money(xu), inline=True)
    e.add_field(name="Giao dịch", value=str(count), inline=False)
    await interaction.response.send_message(embed=e, ephemeral=True)

@bot.tree.command(name="stock", description="Xem cửa hàng và số lượng hàng hiện có")
@app_commands.check(guild_only)
async def stock(interaction: discord.Interaction):
    now = int(time.time())
    with connect() as con:
        refresh_stock_if_needed(con, interaction.guild_id, now)
        rows = con.execute(
            "SELECT item,quantity FROM stock WHERE guild_id=? ORDER BY item",
            (interaction.guild_id,),
        ).fetchall()
    e = embed("🛒 THEWARRIOR SHOP", "Stock tự làm mới mỗi 1 giờ.")
    for row in rows:
        p = PRODUCTS[row["item"]]
        symbol = "💶" if p["currency"] == "token" else "💵"
        e.add_field(
            name=row["item"],
            value=f"Giá: **{money(p['price'])} {symbol}**\nCòn: **{row['quantity']}**",
            inline=True,
        )
    await interaction.response.send_message(embed=e, ephemeral=True)

product_choices = [
    app_commands.Choice(name=name, value=name) for name in PRODUCTS
]

@bot.tree.command(name="buy", description="Mua vật phẩm trong cửa hàng")
@app_commands.describe(item="Vật phẩm muốn mua", quantity="Số lượng muốn mua")
@app_commands.choices(item=product_choices)
async def buy(interaction: discord.Interaction, item: app_commands.Choice[str], quantity: app_commands.Range[int, 1, 99]):
    if not interaction.guild:
        return await interaction.response.send_message("Lệnh chỉ dùng trong server.", ephemeral=True)
    name = item.value
    product = PRODUCTS[name]
    currency = product["currency"]
    base = product["price"] * quantity
    tax = int(base * BUY_TAX_RATE + 0.5)
    total = base + tax
    now = int(time.time())
    symbol = "💶" if currency == "token" else "💵"

    with connect() as con:
        con.execute("BEGIN IMMEDIATE")
        ensure_wallet(con, interaction.guild_id, interaction.user.id)
        refresh_stock_if_needed(con, interaction.guild_id, now)
        stock_row = con.execute(
            "SELECT quantity FROM stock WHERE guild_id=? AND item=?",
            (interaction.guild_id, name),
        ).fetchone()
        wallet = con.execute(
            f"SELECT {currency} AS balance FROM wallets WHERE guild_id=? AND user_id=?",
            (interaction.guild_id, interaction.user.id),
        ).fetchone()
        if not stock_row or stock_row["quantity"] < quantity:
            return await interaction.response.send_message("❌ Stock không đủ số lượng bạn muốn mua.", ephemeral=True)
        if wallet["balance"] < total:
            return await interaction.response.send_message(
                f"❌ Số dư không đủ. Cần **{money(total)} {symbol}** (đã gồm thuế 20%), bạn có **{money(wallet['balance'])} {symbol}**.",
                ephemeral=True,
            )
        con.execute(
            f"UPDATE wallets SET {currency}={currency}-? WHERE guild_id=? AND user_id=?",
            (total, interaction.guild_id, interaction.user.id),
        )
        con.execute(
            "UPDATE stock SET quantity=quantity-? WHERE guild_id=? AND item=?",
            (quantity, interaction.guild_id, name),
        )
        con.execute(
            """INSERT INTO inventory(guild_id,user_id,item,quantity) VALUES(?,?,?,?)
               ON CONFLICT(guild_id,user_id,item) DO UPDATE SET quantity=quantity+excluded.quantity""",
            (interaction.guild_id, interaction.user.id, name, quantity),
        )
        con.execute(
            """INSERT INTO transactions(guild_id,actor_id,kind,currency,amount,tax,created_at)
               VALUES(?,?, 'purchase',?,?,?,?)""",
            (interaction.guild_id, interaction.user.id, currency, base, tax, now),
        )
    e = embed("✅ Mua hàng thành công", f"Bạn đã mua **{quantity} × {name}**.")
    e.add_field(name="Giá gốc", value=f"{money(base)} {symbol}")
    e.add_field(name="Thuế 20%", value=f"{money(tax)} {symbol}")
    e.add_field(name="Tổng thanh toán", value=f"**{money(total)} {symbol}**")
    await interaction.response.send_message(embed=e, ephemeral=True)

@bot.tree.command(name="pay", description="Chuyển Token hoặc Xu cho thành viên khác")
@app_commands.choices(currency=[
    app_commands.Choice(name="Token 💶", value="token"),
    app_commands.Choice(name="Xu 💵", value="xu"),
])
@app_commands.describe(member="Người nhận", amount="Số tiền người nhận sẽ nhận", currency="Loại tiền")
async def pay(interaction: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1, 1000000000], currency: app_commands.Choice[str]):
    if not interaction.guild:
        return await interaction.response.send_message("Lệnh chỉ dùng trong server.", ephemeral=True)
    if member.bot or member.id == interaction.user.id:
        return await interaction.response.send_message("❌ Không thể chuyển cho bot hoặc chính bạn.", ephemeral=True)
    cur = currency.value
    tax_rate = random.uniform(TRANSFER_TAX_MIN, TRANSFER_TAX_MAX)
    tax = int(amount * tax_rate + 0.5)
    debit = amount + tax
    now = int(time.time())
    symbol = "💶" if cur == "token" else "💵"
    with connect() as con:
        con.execute("BEGIN IMMEDIATE")
        ensure_wallet(con, interaction.guild_id, interaction.user.id)
        ensure_wallet(con, interaction.guild_id, member.id)
        sender = con.execute(
            f"SELECT {cur} AS balance FROM wallets WHERE guild_id=? AND user_id=?",
            (interaction.guild_id, interaction.user.id),
        ).fetchone()
        if sender["balance"] < debit:
            return await interaction.response.send_message(
                f"❌ Không đủ số dư. Cần **{money(debit)} {symbol}** gồm cả thuế; hiện có **{money(sender['balance'])} {symbol}**.",
                ephemeral=True,
            )
        con.execute(
            f"UPDATE wallets SET {cur}={cur}-? WHERE guild_id=? AND user_id=?",
            (debit, interaction.guild_id, interaction.user.id),
        )
        con.execute(
            f"UPDATE wallets SET {cur}={cur}+? WHERE guild_id=? AND user_id=?",
            (amount, interaction.guild_id, member.id),
        )
        con.execute(
            """INSERT INTO transactions(guild_id,actor_id,target_id,kind,currency,amount,tax,created_at)
               VALUES(?,?,?,'transfer',?,?,?,?)""",
            (interaction.guild_id, interaction.user.id, member.id, cur, amount, tax, now),
        )
    e = embed("✅ Chuyển tiền thành công",
              f"Bạn đã chuyển thành công cho **{member.display_name}**: **{money(amount)} {symbol}**.")
    e.add_field(name="Thuế giao dịch", value=f"{money(tax)} {symbol} ({tax_rate*100:.1f}%)")
    e.add_field(name="Tổng bị trừ", value=f"{money(debit)} {symbol}")
    await interaction.response.send_message(embed=e, ephemeral=True)
    try:
        await member.send(f"Bạn nhận được **{money(amount)} {symbol}** từ **{interaction.user.display_name}** trong server **{interaction.guild.name}**.")
    except discord.Forbidden:
        pass

@bot.tree.command(name="trade", description="Đổi Token 💶 sang Xu 💵")
@app_commands.describe(token_amount="Số Token muốn đổi; mỗi 1.000 Token = 1 Xu")
async def trade(interaction: discord.Interaction, token_amount: app_commands.Range[int, 1000, 1000000000]):
    if not interaction.guild:
        return await interaction.response.send_message("Lệnh chỉ dùng trong server.", ephemeral=True)
    if token_amount % EXCHANGE_TOKEN_PER_XU != 0:
        return await interaction.response.send_message("❌ Số Token phải chia hết cho 1.000.", ephemeral=True)
    xu_amount = token_amount // EXCHANGE_TOKEN_PER_XU
    with connect() as con:
        con.execute("BEGIN IMMEDIATE")
        ensure_wallet(con, interaction.guild_id, interaction.user.id)
        row = con.execute(
            "SELECT token FROM wallets WHERE guild_id=? AND user_id=?",
            (interaction.guild_id, interaction.user.id),
        ).fetchone()
        if row["token"] < token_amount:
            return await interaction.response.send_message(
                f"❌ Bạn không đủ số dư Token 💶. Cần {money(token_amount)}, hiện có {money(row['token'])}.",
                ephemeral=True,
            )
        con.execute(
            "UPDATE wallets SET token=token-?, xu=xu+? WHERE guild_id=? AND user_id=?",
            (token_amount, xu_amount, interaction.guild_id, interaction.user.id),
        )
        con.execute(
            """INSERT INTO transactions(guild_id,actor_id,kind,currency,amount,tax,created_at)
               VALUES(?,?, 'trade','token',?,0,?)""",
            (interaction.guild_id, interaction.user.id, token_amount, int(time.time())),
        )
    await interaction.response.send_message(
        f"✅ Bạn đã đổi thành công **{money(token_amount)} Token 💶** thành **{money(xu_amount)} Xu 💵**.",
        ephemeral=True,
    )

@bot.tree.command(name="toptokenandxu", description="Xem bảng xếp hạng Token và Xu của server")
async def toptokenandxu(interaction: discord.Interaction):
    if not interaction.guild:
        return await interaction.response.send_message("Lệnh chỉ dùng trong server.", ephemeral=True)
    with connect() as con:
        token_rows = con.execute(
            "SELECT user_id,token FROM wallets WHERE guild_id=? ORDER BY token DESC LIMIT 10",
            (interaction.guild_id,),
        ).fetchall()
        xu_rows = con.execute(
            "SELECT user_id,xu FROM wallets WHERE guild_id=? ORDER BY xu DESC LIMIT 10",
            (interaction.guild_id,),
        ).fetchall()
    async def format_rows(rows, field):
        lines = []
        for i, row in enumerate(rows, 1):
            member = interaction.guild.get_member(row["user_id"])
            name = member.display_name if member else f"User {row['user_id']}"
            lines.append(f"**{i}.** {name} — {money(row[field])}")
        return "\n".join(lines) or "Chưa có dữ liệu."
    e = embed("🏆 THEWARRIOR LEADERBOARD")
    e.add_field(name="💶 Top Token", value=await format_rows(token_rows, "token"), inline=False)
    e.add_field(name="💵 Top Xu", value=await format_rows(xu_rows, "xu"), inline=False)
    await interaction.response.send_message(embed=e)

@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    message = "❌ Có lỗi khi thực hiện lệnh. Hãy thử lại sau."
    if isinstance(error, app_commands.MissingPermissions):
        message = "❌ Bạn không có quyền sử dụng lệnh này."
    elif isinstance(error, app_commands.CheckFailure):
        message = "❌ Lệnh này chỉ dùng trong server Discord."
    elif isinstance(error, app_commands.CommandOnCooldown):
        message = "⏳ Bạn đang thao tác quá nhanh, hãy thử lại sau."
    if interaction.response.is_done():
        await interaction.followup.send(message, ephemeral=True)
    else:
        await interaction.response.send_message(message, ephemeral=True)

if not TOKEN:
    raise RuntimeError("Thiếu DISCORD_TOKEN. Hãy thêm Token vào Replit Secrets.")
bot.run(TOKEN)
