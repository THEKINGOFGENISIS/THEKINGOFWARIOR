# TheWarrior Discord Bot

Discord economy bot using Python, discord.py and SQLite.

## Commands
- `/status` — private balance display.
- `/buy` — buy a virtual shop item; 20% tax.
- `/stock` — view rotating stock (refreshes every hour).
- `/pay` — transfer Token or Xu; sender pays a random 5–15% fee.
- `/trade` — exchange Token to Xu at 1,000 Token = 1 Xu.
- `/toptokenandxu` — separate top-10 Token and Xu leaderboards.

There are no moderation commands, `/help`, or `/info`.

## Run on Replit (mobile-friendly)
1. Create a Python Repl and upload `main.py` and `requirements.txt`.
2. Add a Replit Secret named `DISCORD_TOKEN` with your bot token as its value.
3. In Discord Developer Portal → Bot, enable **Message Content Intent**.
4. Install dependencies from `requirements.txt` (Replit normally detects this automatically).
5. Run `python main.py`.

Keep the token private. If it is exposed, reset it in the Developer Portal.

## Notes
- Message rewards: 250 Token per eligible message, with a 10-second per-user cooldown per server to reduce spam farming.
- Discord's Message Content Intent is required for message rewards.
- The bot must remain running for commands and rewards to work.
- SQLite persists balances, inventory, stock, and transactions as long as the host preserves the database file.
- Shop items/prices are sample virtual products defined in `PRODUCTS` near the top of `main.py`; edit them before launch if desired.
- `/clear`, `/kick`, `/ban`, `/unban`, `/help`, and `/info` are intentionally not included.
- The `/buy` command deducts the purchase amount plus 20% tax. `/pay` sends the requested amount to the recipient and charges the sender an additional random 5–15% fee.
